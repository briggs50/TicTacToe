﻿Title:			Tic-Tac-Toe Game Application
Description:	This application allows two users playing a 4x4 tic-tac-toe game using the console UI. 
				The purpose of the application to demonstrate encapsulation and the MVC design pattern.
Authors:		John E Velis (base code), Jennifer Berigan & Alexandra Briggs (updates and enhancements)
Dated Created:	6/12/2015
Last Modified:	9/25/2016
Instructions for Use: